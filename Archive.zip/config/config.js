module.exports = {
    port : 3400,
    dbConnection : "mongodb://localhost:27017/CRM",
    secret : "ItIdeology123",
    encryptionKey : "sdfuyaoesrq2rkjdfo2523945789eryalkmc&%@&$293"
}
